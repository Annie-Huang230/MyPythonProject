"""
File: name_sq.py (extension)
Name: 
----------------------------
This program is an extension of assignment3!
It will ask the user to provide a name, 
and the square pattern of the given name 
will be printed on the console.
"""


def main() :
    """
    TODO:
    """
    pass


# DO NOT EDIT CODE BELOW THIS LINE #

if __name__ == '__main__':
    main()
